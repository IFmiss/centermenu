# centermenu
弹出层，选择菜单在中间的样式插件

在线预览地址: http://www.daiwei.org/components/centermenu/

* ## 参数

* ### liWidth 
列表的宽度,也就是ul的宽度

* ### liHeight
列表的高度

* ### zIndex 
列表的层级

* ### animateIn 
进入的动画

* ### animateOut
离开的动画

* ### hasLineBorder
是否有边框分割线

* ### duration
动画执行的时间

* ### source
列表内容  是个数组  类型

* ### click:function(ret){}
点击的事件方法 有ret返回值 
ret.ele:点击的元素<br>
ret.index:点击的索引<br>
ret.text:点击的文本内容<br>
 
